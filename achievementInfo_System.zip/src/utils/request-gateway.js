import axios from "axios";
// import store from 'src/store'
// import storage from 'store'
import notification from "ant-design-vue/es/notification";
import { VueAxios } from "./axios";
// import { ACCESS_TOKEN } from '@/store/mutation-types'

const devBaseUrl = "";
const proBaseUrl = "";
let url;
process.env.NODE_ENV === "development"
  ? (url = devBaseUrl)
  : (url = proBaseUrl);
// 创建 axios 实例
const request = axios.create({
  // API 请求的默认前缀
  baseURL: url
  // timeout: 20000 // 请求超时时间
});

// 异常拦截处理器
const errorHandler = error => {
  if (error.response) {
    const data = error.response.data;
    if (error.response.status === 403) {
      notification.error({
        message: "请求失败",
        description: data.Msg
      });
    }
    if (error.response.status === 401 && !data.Data) {
      notification.error({
        message: "没有权限",
        description: "请登录后重试或联系系统管理员。"
      });
      sessionStorage.removeItem("userdata");
      window.location.reload();
    }
    if (error.response.status === 500) {
      notification.error({
        message: "请求失败",
        description: data.Msg || "请稍后重试或联系系统管理员。"
      });
      // sessionStorage.removeItem("userdata");
      // window.location.reload();
    }
  }
  return Promise.reject(error);
};

// request interceptor
request.interceptors.request.use(config => {
  const userdata = JSON.parse(sessionStorage.getItem("userdata"));
  if (userdata) {
    config.headers["spatiotemporal_platform_token"] = userdata.token;
  }
  return config;
}, errorHandler);

// response interceptor
request.interceptors.response.use(response => {
  if (response.data.code === 5016) {
    sessionStorage.removeItem("userdata");
    window.location.reload();
  }
  return response.data;
}, errorHandler);

const installer = {
  vm: {},
  install(Vue) {
    Vue.use(VueAxios, request);
  }
};

export default request;

export { installer as VueAxios, request as axios };

// formData
export const postRequest = (url, params) => {
  const headers = {
    "Content-Type": "application/x-www-form-urlencoded"
  };
  if (url === "/api-uaa/oauth/user/token") {
    headers.Authorization = "Basic d2ViQXBwOndlYkFwcA==";
  }
  return request({
    method: "post",
    url: url,
    data: params,
    transformRequest: [
      function(data) {
        const str = [];
        for (const it in data) {
          str.push(encodeURIComponent(it) + "=" + encodeURIComponent(data[it]));
        }
        return str.join("&");
      }
    ],
    headers
  });
};

export const getRequest = (url, data = "") => {
  return request({
    headers: {
      "Content-Type": "application/json;charset=UTF-8"
    },
    method: "get",
    params: data,
    url: url
  });
};
export const getRequestBlob = (url, data = "") => {
  return request({
    headers: {
      "Content-Type": "application/json;charset=UTF-8"
    },
    method: "get",
    params: data,
    url: url,
    responseType: "blob"
  });
};

export const postRequestBlob = (url, params = "") => {
  return request({
    headers: {
      "Content-Type": "application/json;charset=UTF-8"
    },
    method: "post",
    data: params,
    url: url,
    responseType: "blob"
  });
};

// 文件导出
export const exportFileRequest = (url, data) => {
  return axios({
    method: "get",
    url: url,
    params: data,
    responseType: "blob",
    headers: {
      "Content-Type": "application/vnd.ms-excel;charset=utf-8"
    }
  });
};

export const putFormRequest = (url, params) => {
  return request({
    method: "put",
    url: url,
    data: params,
    transformRequest: [
      function(data) {
        const str = [];
        for (const it in data) {
          str.push(encodeURIComponent(it) + "=" + encodeURIComponent(data[it]));
        }
        return str.join("&");
      }
    ]
  });
};

// RequestBody
export const postJsonRequest = (url, params) => {
  return request({
    method: "post",
    url: url,
    data: params,
    headers: {
      "Content-Type": "application/json"
    }
  });
};
// RequestBody
export const postJsonRequestMultipart = (url, params) => {
  return request({
    method: "post",
    url: url,
    data: params,
    headers: {
      "Content-Type": "multipart/form-data"
    }
  });
};

export const putRequest = (url, params) => {
  return request({
    method: "put",
    url: url,
    data: params,
    headers: {
      "Content-Type": "application/json"
    }
  });
};

export const deleteRequest = (url, params) => {
  const headers = {
    "Content-Type": "application/x-www-form-urlencoded"
  };
  return request({
    method: "delete",
    url: url,
    data: params,
    transformRequest: [
      function(data) {
        const str = [];
        for (const it in data) {
          str.push(encodeURIComponent(it) + "=" + encodeURIComponent(data[it]));
        }
        return str.join("&");
      }
    ],
    headers
  });
};

export const postFileRequest = (url, params) => {
  return request({
    method: "post",
    url: url,
    data: params,
    headers: {
      "Content-Type": "multipart/form-data"
    }
  });
};
