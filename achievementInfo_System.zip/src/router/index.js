import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from "../views/login";
import Home from '../views/home'
import NoPermission from "../views/403";

Vue.use(VueRouter)

const routes = [
  {
    path: "/403",
    name: "NoPermission",
    component: NoPermission
  },
  {
    path: "/login",
    name: "Login",
    component: Login
  },
  {
    path: "/",
    name: "cgxxgl",
    component: Home,
    redirect: '/cgxxgl/cgxxgl_lr',
    children: [
      {
        path: "/cgxxgl/cgxxgl_lr",
        name: "cgxxgl_lr",
        component: () => import('@/views/cgxxgl/cgxxgl_lr'),
      },
      {
        path: "/cgxxgl/cgxxgl_sb",
        name: "cgxxgl_sb",
        component: () => import('@/views/cgxxgl/cgxxgl_sb'),
      },
      {
        path: "/cgxxgl/cgxxgl_sh",
        name: "cgxxgl_sh",
        component: () => import('@/views/cgxxgl/cgxxgl_sh'),
      },
      {
        path: "/cgxxgl/cgxxgl_fb",
        name: "cgxxgl_fb",
        component: () => import('@/views/cgxxgl/cgxxgl_fb'),
      },
      {
        path: "/cgxxgl/cgxxgl_lx",
        name: "cgxxgl_lx",
        component: () => import('@/views/cgxxgl/cgxxgl_lx'),
      },
      {
        path: "/cgyygl/cgyygl_sl",
        name: "cgyygl_sl",
        component: () => import('@/views/cgyygl/cgyygl_sl'),
      },
      {
        path: "/cgyygl/cgyygl_sb",
        name: "cgyygl_sb",
        component: () => import('@/views/cgyygl/cgyygl_sb'),
      }
    ]
  }, {
    path: "/cgxxfw",
    name: "cgxxfw",
    component: () => import('@/views/cgxxfw/cgxxfw'),
  }
]

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});
// router.beforeEach((to, from, next) => {
//   let token = sessionStorage.getItem("userdata");
//   if (to.path === "/login") {
//     next();
//   } else if (to.path === "/403") {
//     next();
//   } else {
//     if (token === null || token === "" || token === "null") {
//       next("/login");
//     } else {
//       next();
//     }
//   }
// });

export default router;
