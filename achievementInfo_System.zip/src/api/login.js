import { getRequest, postJsonRequest } from "@/utils/request-gateway";

const userApi = {
  loginFunc: window.platform + "/user_login", // 登录
  loginMD5Func: window.platform + "/user_md5Login", // MD5登录
  logoutFunc: window.platform + "/user_logout" // 登出
};

// 登录
export function loginFunc(parameter) {
  return postJsonRequest(userApi.loginFunc, parameter);
}

// 登出
export function logoutFunc(parameter) {
  return getRequest(userApi.logoutFunc, parameter);
}

// MD5登录
export function loginMD5Func(parameter) {
  return getRequest(userApi.loginMD5Func, parameter);
}
