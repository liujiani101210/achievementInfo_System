<template>
  <div>
    成果信息服务
  </div>
</template>

<script>
    export default {
        name: "cgxxfw"
    }
</script>

<style scoped>

</style>
