<template>
  <div class="login">
    <div class="login_left">
      <div class="title">
        <!-- <img src="../assets/images/title.png" alt /> -->
        <h1 style="font-size:32px;">
<!--          <img-->
<!--            style="width: 50px;margin-right: 20px;"-->
<!--            src="../assets/images/logo.png"-->
<!--            alt-->
<!--          />-->
          成果信息管理系统
        </h1>
      </div>
      <div class="icon">
<!--        <img src="../assets/images/icon.png" alt />-->
      </div>
    </div>
    <a-form :form="form" class="login-form login_right">
      <div class="title">用户登录</div>
      <div class="content">
        <div>
          <a-input v-model="form.account" placeholder="请输入用户名">
            <a-icon slot="prefix" type="user" />
          </a-input>
        </div>
        <div>
          <a-input
            type="password"
            v-model="form.password"
            placeholder="请输入用户密码"
          >
            <a-icon slot="prefix" type="lock" />
          </a-input>
        </div>
      </div>
      <div class="btn">
        <a-button
          html-type="submit"
          class="btn"
          :loading="loginBtn"
          :disabled="loginBtn"
          @click="handleSubmit()"
          >登录</a-button
        >
      </div>
    </a-form>
  </div>
</template>

<script>
import { loginFunc } from "@/api/login"; // loginMD5Func
export default {
  name: "Login",
  components: {},
  data() {
    return {
      loginBtn: false,
      form: {
        account: "",
        password: ""
      }
    };
  },
  mounted() {
  },
  methods: {
    handleSubmit(type) {
      this.loginBtn = true;
      if (this.form.account === "" || this.form.password === "") {
        this.$notification["error"]({
          message: "错误",
          description: "请输入用户名或密码",
          duration: 4
        });
        this.loginBtn = false;
        return false;
      }
      loginFunc(this.form)
        .then(res => {
          if (res.code === "0") {
            sessionStorage.setItem("userdata", JSON.stringify(res.data));
            this.$message.success("登录成功！");
            this.$router.push({path: "/home"});
          }
        })
        .catch(() => {
          this.$message.error("登录失败");
          if (type == "form") {
            this.$router.push({ path: "/403" });
          }
        })
        .finally(() => {
          this.loginBtn = false;
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.login {
  width: 100%;
  height: 100%;
  display: flex;
  .login_left {
    padding: 5% 0;
    width: 70%;
    /*background-image: url("../assets/images/bg.png");*/
    background-size: 100% 100%;
    background-repeat: no-repeat;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    .title {
      width: 38%;
      img {
        width: 100%;
      }
    }
    .icon {
      width: 45%;
      img {
        width: 100%;
      }
    }
  }
  .login_right {
    flex: 1;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    .title {
      color: #049aef;
      font-size: 30px;
      font-weight: bold;
      font-family: MicrosoftYaHei;
      letter-spacing: 4px;
      padding-bottom: 20px;
    }
    .content {
      width: 100%;
      padding: 0 10%;
      > div {
        padding: 10px 0;
      }
      /deep/ .anticon {
        font-size: 16px;
        /*color: #049AEF;*/
        padding-left: 5px;
      }
      /deep/ .ant-input {
        font-size: 16px;
        color: #666666;
        border: 2px solid #c3bebe;
        border-radius: 25px;
        height: 45px;
        padding-left: 40px;
        &::placeholder {
          color: #c3bebe;
        }
      }
      /deep/ .ant-input:focus {
        border: 2px solid #049aef;
        border-right-width: 2px;
        box-shadow: none;
      }
    }
    .btn {
      width: 100%;
      margin: 10px 0;
      padding: 0 10%;
      /deep/ .ant-btn {
        border: none;
        width: 100%;
        height: 40px;
        background: linear-gradient(45deg, #23cffd, #1f81e7);
        border-radius: 40px;
        color: #ffffff;
        font-size: 18px;
      }
    }
  }
}
</style>
