<template>
  <div>
    成果信息录入
  </div>
</template>

<script>
    export default {
        name: "cgxxgl_lr"
    }
</script>

<style scoped>

</style>
