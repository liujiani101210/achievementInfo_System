<template>
  <div>
    成果信息审核
  </div>
</template>

<script>
    export default {
        name: "cgxxgl_sh"
    }
</script>

<style scoped>

</style>
