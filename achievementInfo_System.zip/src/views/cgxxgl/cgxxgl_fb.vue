<template>
  <div>
    成果信息发布
  </div>
</template>

<script>
    export default {
        name: "cgxxgl_fb"
    }
</script>

<style scoped>

</style>
