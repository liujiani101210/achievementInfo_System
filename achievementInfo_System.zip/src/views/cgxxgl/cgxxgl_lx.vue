<template>
  <div>
    离线导入导出
  </div>
</template>

<script>
    export default {
        name: "cgxxgl_lx"
    }
</script>

<style scoped>

</style>
