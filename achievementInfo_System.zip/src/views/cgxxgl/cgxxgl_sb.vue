<template>
  <div>
    成果信息上报
  </div>
</template>

<script>
    export default {
        name: "cgxxgl_sb"
    }
</script>

<style scoped>

</style>
