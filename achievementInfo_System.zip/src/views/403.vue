<template>
  <div class="middle-box text-center">
    <h1>403</h1>
    <h3 class="font-bold">您没有权限！</h3>
    <div class="error-desc">
      访问失败，请联系管理员授权！
    </div>
  </div>
</template>
<script>
export default {
  name: "noPermission"
};
</script>
<style type="text/css">
.middle-box {
  max-width: 400px;
  z-index: 100;
  margin: 0 auto;
  padding-top: 40px;
}

.middle-box h1 {
  font-size: 170px;
  margin: 0px;
}

.text-center {
  text-align: center;
}
</style>
