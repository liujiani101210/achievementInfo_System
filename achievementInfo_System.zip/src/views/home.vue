<template>
  <div id="home">
    <transition name="navTransit">
      <platform-nav v-if="navShow" @titleRender="titleRenderFunc"></platform-nav>
    </transition>
    <div class="container">
      <div class="con_title_box">
        <div class="con_title_box_l">
          <div class="back_btn" @click="navShowFunc"><a-icon :type="navShow?'backward':'forward'" /></div>
          <div class="title_con">{{title}} > <span style="color: #2113ff">{{subTitle}}</span></div>
        </div>
        <div class="con_title_box_r">
          <a-dropdown overlayClassName="dropdown_class">
            <span class="ant-dropdown-link" @click="e => e.preventDefault()">
              <a-avatar icon="user" /> Admin <a-icon type="caret-down" />
            </span>
            <a-menu slot="overlay">
              <a-menu-item>
                <a href="javascript:;"><a-icon type="poweroff" /> 退出登录</a>
              </a-menu-item>
            </a-menu>
          </a-dropdown>
        </div>
      </div>
      <div class="con_info_box">
        <router-view />
      </div>
    </div>
  </div>
</template>
<script>
import PlatformNav from "@/components/PlatformNav.vue";
export default {
  name: "home",
  data() {
    return {
      navShow: true,
      title: '',
      subTitle: ''
    }
  },
  components: {
    PlatformNav
  },
  mounted() {
  },
  methods: {
    navShowFunc() {
      this.navShow = !this.navShow
    },
    titleRenderFunc(titleObj) {
      this.title = titleObj.title
      this.subTitle = titleObj.subTitle
    }
  }
};
</script>

<style lang="less">
#home{
  width: 100%;
  height: 100%;
  overflow: hidden;
  display: flex;
  .navTransit-enter-active, .navTransit-leave-active {
    transition: width 0.3s
  }
  .navTransit-enter, .navTransit-leave-active {
    width: 0
  }
  .container{
    text-align: left;
    flex: 1;
    display: flex;
    flex-direction: column;
    .con_title_box{
      width: 100%;
      height: 80px;
      box-shadow: 0px 1px 5px 0px rgba(0,0,0,0.15);
      display: flex;
      justify-content: space-between;
      align-items: center;
      .con_title_box_l{
        display: flex;
        align-items: center;
        .back_btn{
          width: 80px;
          height: 80px;
          line-height: 80px;
          background: #f7f8f9;
          color: #999898;
          text-align: center;
          font-size: 24px;
          cursor: pointer;
        }
        .title_con{
          padding-left: 10px;
          font-size: 20px;
          font-family: Source Han Sans CN Light, Source Han Sans CN Light-Light;
          font-weight: 300;
          color: #616467;
          letter-spacing: 1px;
        }
      }
      .con_title_box_r{
        padding-right: 10px;
        cursor: pointer;
        height: 80px;
        line-height: 80px;
        .ant-avatar{
          margin-right: 5px;
        }
        .anticon{
          color: #96a5b3;
        }

      }
    }
    .con_info_box{
      width: 100%;
      flex: 1;
    }
  }
}
</style>
<style lang="less">
  .dropdown_class{
    /deep/ .ant-dropdown-menu {
      margin-top: 15px;
    }
  }
</style>
