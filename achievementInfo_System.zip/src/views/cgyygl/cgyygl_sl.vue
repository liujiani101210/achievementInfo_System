<template>
  <div>
    成果应用申领
  </div>
</template>

<script>
    export default {
        name: "cgyygl_sl"
    }
</script>

<style scoped>

</style>
