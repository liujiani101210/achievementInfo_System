<template>
  <div>
    成果应用上报
  </div>
</template>

<script>
    export default {
        name: "cgyygl_sb"
    }
</script>

<style scoped>

</style>
