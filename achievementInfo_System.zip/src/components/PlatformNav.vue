<template>
  <div class="nav_box">
    <div class="nav_title">成果信息管理系统</div>
    <a-menu
      class="nav_list"
      :selected-keys="selectedKeys"
      :open-keys.sync="openKeys"
      mode="inline"
      theme="dark"
    >

<!--      <a-sub-menu key="cgxxgl" @titleClick="titleClick">-->
<!--        <span slot="title"><span>成果信息管理</span></span>-->
<!--        <a-menu-item key="cgxxgl_lr">-->
<!--          成果信息录入-->
<!--        </a-menu-item>-->
<!--        <a-menu-item key="cgxxgl_sb">-->
<!--          成果信息上报-->
<!--        </a-menu-item>-->
<!--        <a-menu-item key="cgxxgl_sh">-->
<!--          成果信息审核-->
<!--        </a-menu-item>-->
<!--        <a-menu-item key="cgxxgl_fb">-->
<!--          成果信息发布-->
<!--        </a-menu-item>-->
<!--        <a-menu-item key="cgxxgl_lx">-->
<!--          离线导入导出-->
<!--        </a-menu-item>-->
<!--      </a-sub-menu>-->
<!--      <a-sub-menu key="cgyygl" @titleClick="titleClick">-->
<!--        <span slot="title"><span>成果应用管理</span></span>-->
<!--        <a-menu-item key="cgyygl_sl">-->
<!--          成果应用申领-->
<!--        </a-menu-item>-->
<!--        <a-menu-item key="cgyygl_sb">-->
<!--          成果应用上报-->
<!--        </a-menu-item>-->
<!--      </a-sub-menu>-->
<!--      <a-menu-item key="cgxxfw">成果信息服务</a-menu-item>-->
<!--      <a-sub-menu key="xtywgl" @titleClick="titleClick">-->
<!--        <span slot="title"><span>系统运维管理</span></span>-->
<!--        <a-menu-item key="xtywgl_hygl">-->
<!--          用户管理-->
<!--        </a-menu-item>-->
<!--      </a-sub-menu>-->
<!--      <a-sub-menu key="sjzdgl" @titleClick="titleClick">-->
<!--        <span slot="title"><span>数据字典管理</span></span>-->
<!--        <a-menu-item key="sjzdgl_zdsx">-->
<!--          字典属性管理-->
<!--        </a-menu-item>-->
<!--      </a-sub-menu>-->

      <template v-for="item in menu">
        <a-sub-menu v-if="item.submenu" :key="item.name" :index="item.title">
          <span slot="title"><span>{{ item.title }}</span></span>
          <a-menu-item
            v-for="subItem in item.submenu"
            :key="subItem.index"
            :index="subItem.index"
          >
            <router-link :to="subItem.path">
              {{ subItem.text }}
            </router-link>
          </a-menu-item>
        </a-sub-menu>
        <a-menu-item v-else :key="item.name" @click="openNew(item)" :index="item.title">{{item.title}}</a-menu-item>
      </template>
    </a-menu>
  </div>
</template>

<script>
export default {
  name: 'PlatformNav',
  data() {
    return {
      menu: [
        {
          title: '成果信息管理',
          name: '/cgxxgl',
          // icon: 'cgxxgl',
          submenu: [
            { text: '成果信息录入', path: '/cgxxgl/cgxxgl_lr', index: '/cgxxgl_lr' },
            { text: '成果信息上报', path: '/cgxxgl/cgxxgl_sb', index: '/cgxxgl_sb' },
            { text: '成果信息审核', path: '/cgxxgl/cgxxgl_sh', index: '/cgxxgl_sh' },
            { text: '成果信息发布', path: '/cgxxgl/cgxxgl_fb', index: '/cgxxgl_fb' },
            { text: '离线导入导出', path: '/cgxxgl/cgxxgl_lx', index: '/cgxxgl_lx' }
          ]
        },{
          title: '成果应用管理',
          name: '/cgyygl',
          submenu: [
            { text: '成果应用申领', path: '/cgyygl/cgyygl_sl', index: '/cgyygl_sl' },
            { text: '成果应用上报', path: '/cgyygl/cgyygl_sb', index: '/cgyygl_sb' }
          ]
        },{
          title: '成果信息服务',
          name: '/cgxxfw'
        },{
          title: '系统运维管理',
          name: '/xtywgl',
          submenu: [
            { text: '用户管理', path: '/xtywgl/xtywgl_hygl', index: '/xtywgl_hygl' }
          ]
        },{
          title: '数据字典管理',
          name: '/sjzdgl',
          submenu: [
            { text: '字典属性管理', path: '/sjzdgl/sjzdgl_zdsx', index: '/sjzdgl_zdsx' }
          ]
        }
      ],
      openKeys: [],
      selectedKeys: [],
    };
  },
  watch: {
    '$route.path':function(newVal){
      this.openKeys = [newVal.substr(0, this.$route.path.lastIndexOf('/'))]
      this.selectedKeys = [newVal.substr(this.$route.path.lastIndexOf('/'))]
      this.getTitle()
    }
  },
  methods: {
    getTitle() {
      const that = this
      let titleObj = {
        title: '',
        subTitle:''
      }
      that.menu.forEach(item => {
        if(item.name === that.openKeys[0]){
          titleObj.title = item.title
          if(item.submenu) {
            item.submenu.forEach(subItem => {
              if(subItem.index === that.selectedKeys[0]){
                titleObj.subTitle = subItem.text
              }
            })
          }
        }
      })
      this.$emit('titleRender',titleObj)
    },
    openNew(item) {
      let routeUrl = this.$router.resolve({
        path: item.name,//新页面地址
        query: {}//携带的参数
      })
      window.open(routeUrl.href, "/path");
    },
  },
  created() {
    this.openKeys = [this.$route.path.substr(0, this.$route.path.lastIndexOf('/'))]
    this.selectedKeys = [this.$route.path.substr(this.$route.path.lastIndexOf('/'))]
  },
  mounted() {
    this.getTitle()
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.nav_box{
  width: 260px;
  height: 100%;
  background: #293846;
  display: flex;
  flex-direction: column;
  .nav_title{
    width: 100%;
    height: 80px;
    line-height: 80px;
    font-size: 18px;
    font-family: Microsoft YaHei Regular, Microsoft YaHei Regular-Regular;
    font-weight: bold;
    text-align: center;
    color: #ffffff;
    letter-spacing: 1px;
  }
  .nav_list{
    width: 100%;
    flex: 1;
    overflow: auto;
    background: #2f4050;
  }
  /deep/ .ant-menu-dark.ant-menu-inline .ant-menu-item, /deep/ .ant-menu-dark.ant-menu-inline .ant-menu-submenu-title {
    display: flex;
    justify-content: space-between;
  }
  /deep/ .ant-menu-dark.ant-menu-inline .ant-menu-submenu-title{
    background: #2f4050;
  }
  /deep/ .ant-menu-dark .ant-menu-inline.ant-menu-sub{
    background: #293846;
  }
  /deep/ .ant-menu.ant-menu-dark .ant-menu-item-selected{
    color: #55a3ff;
    background-color: transparent;
  }
  /deep/ .ant-menu-dark .ant-menu-item-selected > a{
    color: #55a3ff;
  }
  .nav_list{
    scrollbar-width: none;
    -ms-overflow-style: none;
  }
  .nav_list::-webkit-scrollbar {
    display: none;
  }

}
</style>
